﻿namespace WebApplication1.Models
{
    public class Car
    {
        public int Id { get; set; }
        public string CompanyName { get; set; } 
        public string Type { get; set; } 
        public string Model { get; set; }  
        public int Year { get; set; }
        public string Licesnse_Plate { get; set; }
        public int Quantity { get; set; }
        public bool Availability { get; set; }
        public int Capacity { get; set; }
        public string Trasnsmission { get; set; }
        public float costPerHour { get; set; }

    }
}
