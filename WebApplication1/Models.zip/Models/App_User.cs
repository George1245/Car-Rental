﻿using Microsoft.AspNetCore.Identity;
using WebApplication1.Repsitory;

namespace WebApplication1.Models
{
    public class App_User:IdentityUser
    {
        
    }
}
